app.controller('teacher-menu', function($scope, $http){

    $scope.dir = dir;
    $scope.students = [];
    $scope.classesLessons = [];
    $scope.lessons = [];
    $scope.data = [];
    $scope.schoolSchedule;
    $scope.lesson;
    $scope.class;

    if(dir == 'pages/teachers/schedule.html')
    {
        $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-schools.php?u=' + user).success(function(data){
            $scope.data = data;
        });
    }

    $scope.startLesson = function()
    {
        $scope.students = [];
        $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-students.php?c=' + $scope.class + '&l=' + $scope.lesson).success(function(data){
            $scope.students = data;
            $scope.dir = 'pages/teachers/attendance-list.html';
        });
    }

    $scope.readAttendances = function(X)
    {
        $scope.students = [];
        $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-attendances.php?c=' + X).success(function(data){
            $scope.students = data;
            $scope.dir = 'pages/teachers/presence-list.html';
        });
    }

    $scope.confirmPresence = function(X, Y)
    {

        var obj = document.getElementById('stu' + Y);

        navigator.notification.confirm(
            'Tem certeza de que deseja confirmar a presença deste aluno?',
            function(X)
            {
                if(X == 2)
                {
                    $http.get('http://robociencia.com.br/app-folder/libs/teachers/insert-presence.php?u=' + user + '&s=' + Y + '&l=' + $scope.lesson).success(function(){
                        if(obj.getElementsByTagName('button')[0].className == 'button button-balanced')
                        {
                            obj.style.background = '#2ecc71';
                            obj.getElementsByTagName('button')[0].className = 'button button-assertive';
                            obj.getElementsByTagName('i')[0].className = 'icon ion-ios-close-outline';
                        }
                        else
                        {
                            obj.style.background = '#fff';
                            obj.getElementsByTagName('button')[0].className = 'button button-balanced';
                            obj.getElementsByTagName('i')[0].className = 'icon ion-ios-checkmark-outline';
                        }
                    });
                }
            },
            'Confirmar presença?',
            ['cancelar', 'tudo bem, entendi']
        );

    }

    $scope.changeSelectedItem = function(X, Y){

        if(Y == 'class')
        {
            $scope.class = X;
        }
        else if(Y == 'lesson')
        {
            $scope.lesson = X;
        }
        else if(Y == 'school')
        {
            $scope.classesLessons = [];
            $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-class-lesson.php?u=' + user + '&s=' + X).success(function(data){
                $scope.classesLessons = data;
            });
        }
        else if(Y == 'schoolSchedule')
        {
            $scope.classesLessons = [];
            $scope.schoolSchedule = X;
            $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-class-lesson.php?u=' + user + '&s=' + X + '&m=' + $scope.month).success(function(data){
                $scope.classesLessons = data;
            });
        }
        else if(Y == 'addStudent')
        {
            $scope.classesLessons = [];
            $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-class-lesson.php?u=' + user + '&s=' + X).success(function(data){
                $scope.classesLessons = data;
            });
        }
        else if(Y == 'month')
        {
            $scope.month = X;
        }
        else if(Y == 'addStudentClass')
        {
            $scope.addStudentClass = X;
        }
    }

    $scope.teacherPages = function(X)
    {
        if(X == 'Vistos')
        {
            $http.get('http://robociencia.com.br/app-folder/libs/teachers/get-lessons-day.php?u=' + user).success(function(data){
                $scope.lessonsDay = data;
                $scope.dir = 'pages/teachers/lessons-done.html';
            });
        }
        else if(X == 'Chamada')
        {
            $scope.dir = 'pages/teachers/schedule.html';
            $scope.classesLessons = [];
        }
        else if(X == 'Cronograma')
        {
            $scope.dir = 'pages/teachers/class-schedule.html';
        }
        else if(X == 'Novo')
        {
            $scope.dir = 'pages/teachers/add-student.html';
        }
    }

});

app.controller('add-student', function($scope, $http){
    $scope.AddStudent = function()
    {
        var req = "http://robociencia.com.br/app-folder/libs/teachers/addStudent.php?n=" + $scope.sName +
            "&ph=" + $scope.sTelefone +
            "&c=" + $scope.addStudentClass +
            "&y=1" +
            "&np=" + $scope.sResponsi +
            "&pp=" + $scope.sResTel;

        $http.post(req).success(function(data){

            $scope.sName = "";
            $scope.sTelefone = "";
            $scope.sResponsi = "";
            $scope.sResTel = "";

            navigator.notification.alert(
                'Operação concluída',
                null,
                'Cadastro de alunos',
                'tudo bem, entendi'
            );

        });
    }
});